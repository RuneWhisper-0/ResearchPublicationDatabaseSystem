# ============================================================
# app.py  —  Research Publication Database System (RPDS) v2.0
# Department of Mechanical Engineering, BUET
# ============================================================
#
# What's new in v2:
#   1. Admin login (6 admins) with 5-try lockout (30s wait)
#   2. "Edited by: admin-X" tracked on every record
#   3. Auto-increment Faculty ID (MEF-01, MEF-02, ...)
#   4. Title Case applied automatically on save
#   5. Multiple authors per publication
#   6. Citations column
#   7. Enhanced search (by ID, name, shows faculty card + pubs)
#   8. PDF report generation (Annual, Accreditation, Custom)
#   9. System Info tab with Chart.js bar charts
#  10. Activity log saved to data/history.txt
#  11. Undo last change (one level)
# ============================================================

from flask import (
    Flask, render_template, request, redirect,
    url_for, flash, session, send_file
)
import json
import os
import time
import io
from datetime import datetime
from functools import wraps  # Needed to build the @require_admin decorator

# PDF library — install with:  pip install reportlab
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Table,
    TableStyle, Spacer, HRFlowable
)

# ============================================================
# APP SETUP
# ============================================================

app = Flask(__name__)
app.secret_key = "rpds_buet_2024_v2"   # Used to protect session cookies

# ============================================================
# FILE PATHS  —  all data lives in the /data folder
# ============================================================

DATA_DIR          = "data"
FACULTY_FILE      = "data/faculty.json"
PUB_FILE          = "data/publications.json"
UNDO_FACULTY_FILE = "data/undo_faculty.json"   # snapshot before last change
UNDO_PUB_FILE     = "data/undo_publications.json"
HISTORY_FILE      = "data/history.txt"         # activity log

# ============================================================
# ADMIN CREDENTIALS
# admin-1 through admin-6, each with a unique password
# ============================================================

ADMIN_CREDENTIALS = {
    "admin-1": "jannat67",
    "admin-2": "abiba68",
    "admin-3": "nirob69",
    "admin-4": "hridoy70",
    "admin-5": "rahat71",
    "admin-6": "nafis72"
}

# Track failed login attempts per IP address.
# Format: { "127.0.0.1": {"count": 0, "locked_until": 0.0} }
# This resets when the server restarts — that is fine for our use case.
login_attempts = {}

# ============================================================
# CONTEXT PROCESSOR
# Makes admin_id available in EVERY template automatically
# so we don't have to pass it from every route.
# ============================================================

@app.context_processor
def inject_globals():
    return {"admin_id": session.get("admin_id")}

# ============================================================
# LOAD AND SAVE FUNCTIONS
# ============================================================

def load_faculty():
    """Read faculty list from disk. Returns [] if file doesn't exist yet."""
    if not os.path.exists(FACULTY_FILE):
        return []
    with open(FACULTY_FILE, "r") as f:
        return json.load(f)

def save_faculty(data):
    """Write faculty list to disk."""
    with open(FACULTY_FILE, "w") as f:
        json.dump(data, f, indent=2)

def load_publications():
    """
    Read publications from disk.
    Also handles migration from old format:
      Old: "sn": "MHK"           (single string, v1 format)
      New: "authors": ["MHK"]    (list, v2 format)
    """
    if not os.path.exists(PUB_FILE):
        return []
    with open(PUB_FILE, "r") as f:
        pubs = json.load(f)

    # Migrate any old-format publications to new format
    for pub in pubs:
        # If old "sn" field exists, convert it to the new "authors" list
        if "sn" in pub and "authors" not in pub:
            pub["authors"] = [pub["sn"]]
            del pub["sn"]
        # Fill in any missing fields with safe defaults
        if "authors"        not in pub: pub["authors"]        = []
        if "citations"      not in pub: pub["citations"]      = 0
        if "url"            not in pub: pub["url"]            = ""
        if "last_edited_by" not in pub: pub["last_edited_by"] = None
        if "last_edited_at" not in pub: pub["last_edited_at"] = None

    return pubs

def save_publications(data):
    """Write publications list to disk."""
    with open(PUB_FILE, "w") as f:
        json.dump(data, f, indent=2)

# ============================================================
# UNDO SYSTEM
# Before every add/edit/delete we save a snapshot.
# The /undo route restores that snapshot.
# ============================================================

def save_undo_snapshot():
    """Save current state of both files as a one-level undo buffer."""
    with open(UNDO_FACULTY_FILE, "w") as f:
        json.dump(load_faculty(), f, indent=2)
    with open(UNDO_PUB_FILE, "w") as f:
        json.dump(load_publications(), f, indent=2)

def restore_undo_snapshot():
    """Restore both files from the last snapshot. Returns True if snapshot existed."""
    if not os.path.exists(UNDO_FACULTY_FILE) or not os.path.exists(UNDO_PUB_FILE):
        return False
    with open(UNDO_FACULTY_FILE, "r") as f:
        save_faculty(json.load(f))
    with open(UNDO_PUB_FILE, "r") as f:
        save_publications(json.load(f))
    return True

# ============================================================
# ACTIVITY LOGGING
# Every add/edit/delete/login action writes one line to history.txt
# ============================================================

def log_activity(admin_id, action, details):
    """Append one line to the history log."""
    os.makedirs(DATA_DIR, exist_ok=True)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] | Admin: {admin_id} | Action: {action} | {details}\n"
    with open(HISTORY_FILE, "a") as f:
        f.write(line)

def get_last_edit_time():
    """Return the timestamp of the most recent log entry."""
    if not os.path.exists(HISTORY_FILE):
        return "No edits recorded yet"
    with open(HISTORY_FILE, "r") as f:
        lines = f.readlines()
    if not lines:
        return "No edits recorded yet"
    # Each line starts with "[YYYY-MM-DD HH:MM:SS]"
    last = lines[-1].strip()
    try:
        return last[1:20]   # Extract just the timestamp
    except:
        return "Unknown"

# ============================================================
# HELPER / VALIDATION FUNCTIONS
# ============================================================

def to_title_case(text):
    """
    Capitalize the first letter of every word.
    Example: "heat transfer in nanofluids" → "Heat Transfer In Nanofluids"
    """
    return text.strip().title()

def generate_next_faculty_id(faculty_list):
    """
    Find the highest existing MEF-XX number and return the next one.
    Example: if MEF-05 is the highest, returns MEF-06.
    If no records exist, returns MEF-01.
    """
    max_num = 0
    for f in faculty_list:
        try:
            # "MEF-05" → split on "-" → take index 1 → "05" → int → 5
            num = int(f["id"].split("-")[1])
            if num > max_num:
                max_num = num
        except:
            pass   # Skip any IDs that don't follow the MEF-XX pattern
    # :02d means "at least 2 digits" so we get 01, 02, ... 09, 10, 11
    return f"MEF-{max_num + 1:02d}"

def faculty_id_exists(faculty_list, fid):
    """Return True if any faculty record has this ID."""
    return any(f["id"] == fid for f in faculty_list)

def faculty_sn_exists(faculty_list, sn, exclude_id=None):
    """
    Return True if the short name is already taken.
    exclude_id lets us skip checking the record being edited (so you can
    save without changing the SN).
    """
    for f in faculty_list:
        if f["sn"].upper() == sn.upper():
            if exclude_id and f["id"] == exclude_id:
                continue   # This is the record we're editing — skip it
            return True
    return False

def pub_title_exists(pub_list, title, exclude_idx=None):
    """Return True if this title already exists (case-insensitive)."""
    for i, p in enumerate(pub_list):
        if p["title"].lower() == title.lower():
            if exclude_idx is not None and i == exclude_idx:
                continue   # Skip the record we're editing
            return True
    return False

def validate_year(year):
    """Return True if year is a number between 1900 and 2030."""
    try:
        y = int(year)
        return 1900 <= y <= 2030
    except:
        return False   # Not a number at all

def now_str():
    """Return current date and time as a readable string."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def get_ra_for_authors(authors, faculty_list):
    """
    Given a list of author short names, return a comma-separated string
    of their research areas. Used in the publications table.
    """
    areas = []
    for sn in authors:
        for f in faculty_list:
            if f["sn"].upper() == sn.upper():
                ra = f.get("ra", "")
                if ra and ra not in areas:
                    areas.append(ra)
    return ", ".join(areas) if areas else "—"

# ============================================================
# ADMIN AUTH  —  login/logout/lockout/decorator
# ============================================================

def require_admin(f):
    """
    A decorator that protects routes behind admin login.
    Put @require_admin above any route that should be admin-only.

    How a decorator works:
      - It wraps the route function
      - Before the real function runs, it checks if admin_id is in the session
      - If not, it redirects to the login page instead
    """
    @wraps(f)
    def protected(*args, **kwargs):
        if "admin_id" not in session:
            flash("Please log in as admin to do this.", "error")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return protected

def get_client_ip():
    """Get the IP address making the current request."""
    return request.remote_addr or "unknown"

def is_locked_out(ip):
    """Return True if this IP is currently locked out (5 failed attempts, 30s wait)."""
    if ip not in login_attempts:
        return False
    info = login_attempts[ip]
    if info["count"] >= 5 and info["locked_until"] > time.time():
        return True   # Still within the lockout window
    # Lockout has expired — reset the counter
    if info.get("locked_until", 0) <= time.time():
        login_attempts[ip] = {"count": 0, "locked_until": 0}
    return False

def seconds_remaining(ip):
    """How many seconds are left in the current lockout."""
    if ip not in login_attempts:
        return 0
    return max(0, int(login_attempts[ip].get("locked_until", 0) - time.time()))

def record_failed_attempt(ip):
    """Count a failed login. Lock out for 30s after 5 failures."""
    if ip not in login_attempts:
        login_attempts[ip] = {"count": 0, "locked_until": 0}
    login_attempts[ip]["count"] += 1
    if login_attempts[ip]["count"] >= 5:
        login_attempts[ip]["locked_until"] = time.time() + 30

def reset_attempts(ip):
    """Clear the failed-attempt counter after a successful login."""
    login_attempts[ip] = {"count": 0, "locked_until": 0}

# ============================================================
# ROUTES  —  AUTH
# ============================================================

@app.route("/login", methods=["GET", "POST"])
def login():
    """Show login form (GET) or process login attempt (POST)."""
    ip = get_client_ip()

    if request.method == "POST":
        admin_id = request.form.get("admin_id", "").strip()
        password = request.form.get("password", "").strip()

        # Check lockout first
        if is_locked_out(ip):
            wait = seconds_remaining(ip)
            flash(f"Too many failed attempts. Please wait {wait} seconds.", "error")
            return render_template("login.html", wait=wait)

        # Check credentials
        if admin_id in ADMIN_CREDENTIALS and ADMIN_CREDENTIALS[admin_id] == password:
            session["admin_id"] = admin_id
            reset_attempts(ip)
            log_activity(admin_id, "LOGIN", "Logged in successfully")
            flash(f"Welcome, {admin_id}!", "success")
            return redirect(url_for("index"))
        else:
            record_failed_attempt(ip)
            tries_left = max(0, 5 - login_attempts.get(ip, {}).get("count", 0))
            flash(f"Wrong ID or password. {tries_left} attempt(s) remaining.", "error")

    return render_template("login.html", wait=0)

@app.route("/logout")
def logout():
    """Log out the current admin."""
    admin_id = session.get("admin_id", "unknown")
    log_activity(admin_id, "LOGOUT", "Logged out")
    session.pop("admin_id", None)
    flash("Logged out successfully.", "success")
    return redirect(url_for("index"))

# ============================================================
# ROUTES  —  MAIN PAGES
# ============================================================

@app.route("/")
def index():
    """Dashboard — overview stats and recent publications."""
    faculty = load_faculty()
    pubs    = load_publications()

    # Count publications per type  →  {"Journal": 10, "Conference": 4, ...}
    pub_types = {}
    for pub in pubs:
        t = pub["type"]
        pub_types[t] = pub_types.get(t, 0) + 1

    # Count publications per year, sorted oldest-first
    year_counts = {}
    for pub in pubs:
        y = pub["year"]
        year_counts[y] = year_counts.get(y, 0) + 1
    year_counts = dict(sorted(year_counts.items()))

    return render_template("index.html",
        faculty=faculty,
        pubs=pubs,
        pub_types=pub_types,
        year_counts=year_counts
    )

@app.route("/system_info")
def system_info():
    """System Info tab — detailed stats + Chart.js bar charts."""
    faculty = load_faculty()
    pubs    = load_publications()

    # -- Publications per Research Area --
    # For each research area, count how many pubs have an author from that RA
    ra_pub_counts  = {}   # {"Heat Transfer": 8, ...}
    ra_fac_counts  = {}   # {"Heat Transfer": 2, ...}

    for f in faculty:
        ra = f.get("ra", "Unknown")
        ra_fac_counts[ra] = ra_fac_counts.get(ra, 0) + 1
        # Count pubs where this faculty is an author
        count = sum(1 for p in pubs if f["sn"] in p.get("authors", []))
        ra_pub_counts[ra] = ra_pub_counts.get(ra, 0) + count

    # -- Faculty-wise publication counts (sorted highest first) --
    faculty_pub_counts = []
    for f in faculty:
        count = sum(1 for p in pubs if f["sn"] in p.get("authors", []))
        faculty_pub_counts.append({
            "name": f["full_name"], "sn": f["sn"], "count": count
        })
    faculty_pub_counts.sort(key=lambda x: x["count"], reverse=True)

    # -- Year-wise counts --
    year_counts = {}
    for p in pubs:
        year_counts[p["year"]] = year_counts.get(p["year"], 0) + 1
    year_counts = dict(sorted(year_counts.items()))

    # -- Type counts --
    type_counts = {}
    for p in pubs:
        type_counts[p["type"]] = type_counts.get(p["type"], 0) + 1

    # -- Faculty by designation (for accreditation overview) --
    desi_counts = {
        "Professor": 0, "Associate Professor": 0,
        "Assistant Professor": 0, "Lecturer": 0
    }
    for f in faculty:
        d = f.get("desi", "")
        if d in desi_counts:
            desi_counts[d] += 1

    avg      = round(len(pubs) / len(faculty), 2) if faculty else 0
    years    = [int(p["year"]) for p in pubs if str(p["year"]).isdigit()]
    min_year = min(years) if years else "N/A"
    max_year = max(years) if years else "N/A"

    return render_template("system_info.html",
        faculty=faculty,
        pubs=pubs,
        faculty_pub_counts=faculty_pub_counts,
        year_counts=year_counts,
        type_counts=type_counts,
        ra_pub_counts=ra_pub_counts,
        ra_fac_counts=ra_fac_counts,
        desi_counts=desi_counts,
        total_pubs=len(pubs),
        total_faculty=len(faculty),
        avg=avg,
        min_year=min_year,
        max_year=max_year,
        last_edit=get_last_edit_time()
    )

@app.route("/history")
@require_admin
def history():
    """Activity log page — shows all logged actions, newest first."""
    entries = []
    if os.path.exists(HISTORY_FILE):
        with open(HISTORY_FILE, "r") as f:
            lines = f.readlines()
        # Reverse so newest entries appear at top
        entries = [line.strip() for line in reversed(lines) if line.strip()]
    return render_template("history.html", entries=entries)

# ============================================================
# ROUTES  —  FACULTY
# ============================================================

@app.route("/faculty")
def faculty_list():
    """Show all faculty members with publication counts."""
    faculty = load_faculty()
    pubs    = load_publications()
    # Attach publication count to each faculty dict for display
    for f in faculty:
        f["pub_count"] = sum(1 for p in pubs if f["sn"] in p.get("authors", []))
    return render_template("faculty.html", faculty=faculty)

@app.route("/faculty/add", methods=["GET", "POST"])
@require_admin
def add_faculty():
    """Add a new faculty member. Faculty ID is auto-generated."""
    faculty = load_faculty()
    next_id = generate_next_faculty_id(faculty)   # Show preview on the form

    if request.method == "POST":
        # Re-generate in case another admin added one while form was open
        faculty = load_faculty()
        new_id  = generate_next_faculty_id(faculty)

        sn          = request.form["sn"].strip().upper()
        full_name   = to_title_case(request.form["full_name"])
        desi        = request.form["desi"].strip()
        ra          = to_title_case(request.form["ra"])       # Title case applied here
        profile_url = request.form.get("profile_url", "").strip()

        # --- Validation ---
        if not sn or not full_name or not desi or not ra:
            flash("All required fields must be filled.", "error")
            return render_template("add_faculty.html", next_id=next_id)

        if faculty_sn_exists(faculty, sn):
            flash(f"Short name '{sn}' is already taken by another faculty.", "error")
            return render_template("add_faculty.html", next_id=next_id)

        # Save snapshot so admin can undo this addition
        save_undo_snapshot()

        faculty.append({
            "id":             new_id,
            "sn":             sn,
            "full_name":      full_name,
            "desi":           desi,
            "ra":             ra,
            "profile_url":    profile_url,
            "last_edited_by": session["admin_id"],
            "last_edited_at": now_str()
        })
        save_faculty(faculty)

        log_activity(session["admin_id"], "ADD_FACULTY",
                     f"Name: {full_name}, ID: {new_id}")
        flash(f"Faculty '{full_name}' added with ID {new_id}!", "success")
        return redirect(url_for("faculty_list"))

    return render_template("add_faculty.html", next_id=next_id)

@app.route("/faculty/edit/<fid>", methods=["GET", "POST"])
@require_admin
def edit_faculty(fid):
    """Edit an existing faculty member's details."""
    faculty = load_faculty()
    member  = next((f for f in faculty if f["id"] == fid), None)

    if not member:
        flash("Faculty not found.", "error")
        return redirect(url_for("faculty_list"))

    if request.method == "POST":
        sn          = request.form["sn"].strip().upper()
        full_name   = to_title_case(request.form["full_name"])
        desi        = request.form["desi"].strip()
        ra          = to_title_case(request.form["ra"])
        profile_url = request.form.get("profile_url", "").strip()

        if faculty_sn_exists(faculty, sn, exclude_id=fid):
            flash(f"Short name '{sn}' is used by another faculty.", "error")
            return render_template("edit_faculty.html", member=member)

        save_undo_snapshot()

        # Update the member dict in-place (this updates it inside the faculty list too)
        member["sn"]             = sn
        member["full_name"]      = full_name
        member["desi"]           = desi
        member["ra"]             = ra
        member["profile_url"]    = profile_url
        member["last_edited_by"] = session["admin_id"]
        member["last_edited_at"] = now_str()

        save_faculty(faculty)
        log_activity(session["admin_id"], "EDIT_FACULTY",
                     f"ID: {fid}, Name: {full_name}")
        flash("Faculty updated successfully!", "success")
        return redirect(url_for("faculty_list"))

    return render_template("edit_faculty.html", member=member)

@app.route("/faculty/delete/<fid>", methods=["POST"])
@require_admin
def delete_faculty(fid):
    """Delete a faculty record permanently."""
    faculty = load_faculty()
    target  = next((f for f in faculty if f["id"] == fid), None)
    name    = target["full_name"] if target else fid

    save_undo_snapshot()
    faculty = [f for f in faculty if f["id"] != fid]   # Keep everyone except this one
    save_faculty(faculty)

    log_activity(session["admin_id"], "DELETE_FACULTY",
                 f"ID: {fid}, Name: {name}")
    flash(f"Faculty '{name}' deleted.", "success")
    return redirect(url_for("faculty_list"))

# ============================================================
# ROUTES  —  PUBLICATIONS
# ============================================================

@app.route("/publications")
def pub_list():
    """Show all publications with authors, citations, and research areas."""
    pubs    = load_publications()
    faculty = load_faculty()
    # Attach the research areas string to each pub for the table column
    for pub in pubs:
        pub["ra_display"] = get_ra_for_authors(pub.get("authors", []), faculty)
    return render_template("publications.html", pubs=pubs, faculty=faculty)

@app.route("/publications/add", methods=["GET", "POST"])
@require_admin
def add_publication():
    """Add a new publication. Supports selecting multiple authors via checkboxes."""
    faculty = load_faculty()

    if request.method == "POST":
        pubs = load_publications()

        title     = to_title_case(request.form["title"])   # Title Case applied
        year      = request.form["year"].strip()
        ptype     = request.form["type"].strip()
        # getlist returns a list of all checked checkbox values
        authors   = request.form.getlist("authors")
        journal   = request.form["journal"].strip()
        url       = request.form.get("url", "").strip()
        indexing  = request.form.get("indexing", "").strip()
        citations = request.form.get("citations", "0").strip()

        # --- Validation ---
        if not title or not year or not ptype or not authors or not journal:
            flash("Title, year, type, at least one author, and journal are required.", "error")
            return render_template("add_publication.html", faculty=faculty)

        if not validate_year(year):
            flash("Year must be a number between 1900 and 2030.", "error")
            return render_template("add_publication.html", faculty=faculty)

        if pub_title_exists(pubs, title):
            flash("A publication with this exact title already exists.", "error")
            return render_template("add_publication.html", faculty=faculty)

        # Convert citations to int, default 0 if blank or invalid
        try:
            citations = int(citations)
        except:
            citations = 0

        save_undo_snapshot()

        pubs.append({
            "title":          title,
            "year":           year,
            "type":           ptype,
            "authors":        authors,    # This is a list, e.g. ["MHK", "SA"]
            "journal":        journal,
            "url":            url,
            "indexing":       indexing,
            "citations":      citations,
            "last_edited_by": session["admin_id"],
            "last_edited_at": now_str()
        })
        save_publications(pubs)

        log_activity(session["admin_id"], "ADD_PUBLICATION",
                     f"Title: {title}, Year: {year}, Authors: {', '.join(authors)}")
        flash("Publication added successfully!", "success")
        return redirect(url_for("pub_list"))

    return render_template("add_publication.html", faculty=faculty)

@app.route("/publications/edit/<int:idx>", methods=["GET", "POST"])
@require_admin
def edit_publication(idx):
    """Edit an existing publication. idx is its position in the list."""
    pubs    = load_publications()
    faculty = load_faculty()

    if idx >= len(pubs):
        flash("Publication not found.", "error")
        return redirect(url_for("pub_list"))

    pub = pubs[idx]

    if request.method == "POST":
        title     = to_title_case(request.form["title"])
        year      = request.form["year"].strip()
        ptype     = request.form["type"].strip()
        authors   = request.form.getlist("authors")
        journal   = request.form["journal"].strip()
        url       = request.form.get("url", "").strip()
        indexing  = request.form.get("indexing", "").strip()
        citations = request.form.get("citations", "0").strip()

        if not validate_year(year):
            flash("Invalid year — must be between 1900 and 2030.", "error")
            return render_template("edit_publication.html", pub=pub, idx=idx, faculty=faculty)

        if pub_title_exists(pubs, title, exclude_idx=idx):
            flash("Another publication with this title already exists.", "error")
            return render_template("edit_publication.html", pub=pub, idx=idx, faculty=faculty)

        try:
            citations = int(citations)
        except:
            citations = 0

        save_undo_snapshot()

        # Update all fields of the publication in-place
        pub["title"]          = title
        pub["year"]           = year
        pub["type"]           = ptype
        pub["authors"]        = authors
        pub["journal"]        = journal
        pub["url"]            = url
        pub["indexing"]       = indexing
        pub["citations"]      = citations
        pub["last_edited_by"] = session["admin_id"]
        pub["last_edited_at"] = now_str()

        save_publications(pubs)
        log_activity(session["admin_id"], "EDIT_PUBLICATION", f"Title: {title}")
        flash("Publication updated!", "success")
        return redirect(url_for("pub_list"))

    return render_template("edit_publication.html", pub=pub, idx=idx, faculty=faculty)

@app.route("/publications/delete/<int:idx>", methods=["POST"])
@require_admin
def delete_publication(idx):
    """Delete a publication by its list index."""
    pubs = load_publications()
    if idx < len(pubs):
        title = pubs[idx]["title"]
        save_undo_snapshot()
        pubs.pop(idx)     # Remove element at position idx
        save_publications(pubs)
        log_activity(session["admin_id"], "DELETE_PUBLICATION", f"Title: {title}")
        flash("Publication deleted.", "success")
    return redirect(url_for("pub_list"))

# ============================================================
# ROUTES  —  SEARCH
# ============================================================

@app.route("/search")
def search():
    """
    Enhanced search with four modes:
      faculty      → by ID, short name, or full name
                     shows faculty profile card + all their pubs (chronological)
      year         → exact year match
      pubtype      → publication type
      research_area→ by faculty research area
      keyword      → title, journal, or indexing (default)
    """
    query       = request.args.get("q", "").strip()
    search_type = request.args.get("type", "keyword")
    pubs        = load_publications()
    faculty     = load_faculty()
    results     = []
    faculty_results = []   # Faculty profile cards shown above pub results

    if query:
        if search_type == "faculty":
            # Search by ID, short name, or any part of the full name
            for f in faculty:
                if (query.upper() == f["id"].upper() or
                    query.upper() == f["sn"].upper() or
                    query.lower() in f["full_name"].lower()):
                    faculty_results.append(f)

            # Get all publications for the matched faculty, chronological order
            matched_sns = [f["sn"] for f in faculty_results]
            results = [p for p in pubs
                       if any(sn in p.get("authors", []) for sn in matched_sns)]
            results = sorted(results, key=lambda x: x["year"])

        elif search_type == "year":
            results = [p for p in pubs if p["year"] == query]

        elif search_type == "pubtype":
            results = [p for p in pubs if query.lower() in p["type"].lower()]

        elif search_type == "research_area":
            # Match faculty whose RA contains the query, then get their pubs
            matched_faculty = [f for f in faculty
                               if query.lower() in f.get("ra", "").lower()]
            matched_sns     = [f["sn"] for f in matched_faculty]
            results         = [p for p in pubs
                               if any(sn in p.get("authors", []) for sn in matched_sns)]
            faculty_results = matched_faculty

        else:  # keyword — default
            results = [p for p in pubs if
                       query.lower() in p["title"].lower() or
                       query.lower() in p["journal"].lower() or
                       query.lower() in p.get("indexing", "").lower()]

    return render_template("search.html",
        results=results,
        faculty_results=faculty_results,
        query=query,
        search_type=search_type,
        faculty=faculty
    )

# ============================================================
# ROUTES  —  UNDO
# ============================================================

@app.route("/undo", methods=["POST"])
@require_admin
def undo():
    """Restore the last snapshot, undoing the most recent change."""
    if restore_undo_snapshot():
        log_activity(session["admin_id"], "UNDO", "Restored previous snapshot")
        flash("Last change has been undone.", "success")
    else:
        flash("Nothing to undo — no snapshot found.", "error")
    # Go back to the page the admin was on
    return redirect(request.referrer or url_for("index"))

# ============================================================
# ROUTES  —  REPORTS (PDF GENERATION)
# ============================================================

@app.route("/reports")
def reports():
    """Show the PDF report generation page."""
    faculty = load_faculty()
    pubs    = load_publications()

    # Build lists for dropdown menus
    research_areas = sorted(set(f.get("ra", "") for f in faculty if f.get("ra")))
    years          = sorted(set(p["year"] for p in pubs), reverse=True)
    pub_types      = sorted(set(p["type"] for p in pubs))

    return render_template("reports.html",
        research_areas=research_areas,
        years=years,
        pub_types=pub_types
    )

@app.route("/reports/generate", methods=["POST"])
def generate_report():
    """
    Build and download a PDF report.
    Three report types:
      annual        → all pubs for a specific year
      accreditation → everything, with designation breakdown
      custom        → filtered by research area, year, or pub type
    """
    report_type   = request.form.get("report_type", "custom")
    filter_by     = request.form.get("filter_by", "")
    filter_value  = request.form.get("filter_value", "")
    selected_year = request.form.get("selected_year", str(datetime.now().year))

    faculty = load_faculty()
    pubs    = load_publications()

    # Build the PDF entirely in memory (no file written to disk)
    buffer = io.BytesIO()

    doc = SimpleDocTemplate(
        buffer, pagesize=A4,
        rightMargin=2*cm, leftMargin=2*cm,
        topMargin=2*cm,   bottomMargin=2*cm
    )

    # --- Text styles ---
    style_title    = ParagraphStyle("t",  fontSize=16, fontName="Helvetica-Bold",
                                    alignment=TA_CENTER, spaceAfter=6)
    style_subtitle = ParagraphStyle("s",  fontSize=10, fontName="Helvetica",
                                    alignment=TA_CENTER, spaceAfter=4,
                                    textColor=colors.grey)
    style_heading  = ParagraphStyle("h",  fontSize=12, fontName="Helvetica-Bold",
                                    spaceBefore=12, spaceAfter=6)
    style_normal   = ParagraphStyle("n",  fontSize=8,  fontName="Helvetica",
                                    spaceAfter=3)
    style_link     = ParagraphStyle("l",  fontSize=8,  fontName="Helvetica",
                                    textColor=colors.blue)

    # --- Table visual style (navy header, alternating rows) ---
    TABLE_STYLE = TableStyle([
        ("BACKGROUND",     (0, 0), (-1,  0), colors.HexColor("#0A1628")),
        ("TEXTCOLOR",      (0, 0), (-1,  0), colors.HexColor("#E8C97A")),
        ("FONTNAME",       (0, 0), (-1,  0), "Helvetica-Bold"),
        ("FONTSIZE",       (0, 0), (-1, -1), 7),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F5F0E8")]),
        ("GRID",           (0, 0), (-1, -1), 0.4, colors.HexColor("#CCCCCC")),
        ("TOPPADDING",     (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING",  (0, 0), (-1, -1), 3),
        ("LEFTPADDING",    (0, 0), (-1, -1), 5),
        ("RIGHTPADDING",   (0, 0), (-1, -1), 5),
        ("VALIGN",         (0, 0), (-1, -1), "TOP"),
    ])

    # --- Helper: make a clickable hyperlink in the PDF ---
    def linked(text, url):
        if url and url.startswith("http"):
            return Paragraph(f'<a href="{url}" color="blue"><u>{text}</u></a>', style_link)
        return Paragraph(text, style_normal)

    # --- Helper: build the summary section included in all reports ---
    def summary_section(pub_subset, fac_subset):
        items = []
        items.append(Paragraph("Summary Statistics", style_heading))
        items.append(Paragraph(f"Total Faculty (in report): {len(fac_subset)}", style_normal))
        items.append(Paragraph(f"Total Publications (in report): {len(pub_subset)}", style_normal))
        items.append(Paragraph(f"Query Generated At: {now_str()}", style_normal))
        items.append(Paragraph(f"Database Last Edited: {get_last_edit_time()}", style_normal))
        items.append(Spacer(1, 0.3*cm))

        # Publications per faculty
        items.append(Paragraph("Publications Per Faculty", style_heading))
        rows = [["Faculty Name", "SN", "Designation", "Count"]]
        for f in fac_subset:
            cnt = sum(1 for p in pub_subset if f["sn"] in p.get("authors", []))
            rows.append([f["full_name"], f["sn"], f.get("desi", ""), str(cnt)])
        t = Table(rows, colWidths=[6*cm, 2*cm, 4*cm, 2*cm])
        t.setStyle(TABLE_STYLE)
        items.append(t)
        items.append(Spacer(1, 0.3*cm))

        # Year-wise
        items.append(Paragraph("Year-wise Publication Count", style_heading))
        yd = {}
        for p in pub_subset:
            yd[p["year"]] = yd.get(p["year"], 0) + 1
        rows = [["Year", "Count"]]
        for yr in sorted(yd):
            rows.append([yr, str(yd[yr])])
        if len(rows) > 1:
            t = Table(rows, colWidths=[4*cm, 4*cm])
            t.setStyle(TABLE_STYLE)
            items.append(t)
        items.append(Spacer(1, 0.3*cm))

        # Type-wise
        items.append(Paragraph("Publication Count by Type", style_heading))
        td = {}
        for p in pub_subset:
            td[p["type"]] = td.get(p["type"], 0) + 1
        rows = [["Type", "Count"]]
        for pt, cnt in td.items():
            rows.append([pt, str(cnt)])
        if len(rows) > 1:
            t = Table(rows, colWidths=[6*cm, 4*cm])
            t.setStyle(TABLE_STYLE)
            items.append(t)

        return items

    # --- Build content depending on report type ---
    content = []

    # Every report starts with this header
    content.append(Paragraph("Department of Mechanical Engineering, BUET", style_subtitle))
    content.append(Spacer(1, 0.2*cm))

    # ---- ANNUAL DEPARTMENTAL REPORT ----
    if report_type == "annual":
        yr_pubs = [p for p in pubs if p["year"] == selected_year]

        content.append(Paragraph(f"Annual Departmental Report — {selected_year}", style_title))
        content.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor("#C9A84C")))
        content.append(Spacer(1, 0.3*cm))

        content.append(Paragraph(f"All Publications in {selected_year}", style_heading))
        rows = [["Title", "Author(s)", "Type", "Journal", "Citations"]]
        for p in yr_pubs:
            rows.append([
                linked(p["title"], p.get("url", "")),
                ", ".join(p.get("authors", [])),
                p["type"], p["journal"],
                str(p.get("citations", 0))
            ])
        if len(rows) > 1:
            t = Table(rows, colWidths=[5.5*cm, 2.5*cm, 2*cm, 3.5*cm, 1.5*cm])
            t.setStyle(TABLE_STYLE)
            content.append(t)
        else:
            content.append(Paragraph(f"No publications found for {selected_year}.", style_normal))

        content.append(Spacer(1, 0.4*cm))
        content.extend(summary_section(yr_pubs, faculty))

    # ---- ACCREDITATION DOCUMENTATION ----
    elif report_type == "accreditation":
        content.append(Paragraph("Accreditation Documentation", style_title))
        content.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor("#C9A84C")))
        content.append(Spacer(1, 0.3*cm))

        # Designation breakdown
        content.append(Paragraph("Faculty by Designation", style_heading))
        desi = {"Professor": 0, "Associate Professor": 0,
                "Assistant Professor": 0, "Lecturer": 0}
        for f in faculty:
            if f.get("desi") in desi:
                desi[f["desi"]] += 1
        rows = [["Designation", "Count"]]
        for d, cnt in desi.items():
            rows.append([d, str(cnt)])
        t = Table(rows, colWidths=[8*cm, 3*cm])
        t.setStyle(TABLE_STYLE)
        content.append(t)
        content.append(Spacer(1, 0.4*cm))

        # All publications
        content.append(Paragraph("All Publications (All Time)", style_heading))
        rows = [["Title", "Author(s)", "Year", "Type", "Journal", "Cited"]]
        for p in sorted(pubs, key=lambda x: x["year"]):
            rows.append([
                linked(p["title"], p.get("url", "")),
                ", ".join(p.get("authors", [])),
                p["year"], p["type"], p["journal"],
                str(p.get("citations", 0))
            ])
        if len(rows) > 1:
            t = Table(rows, colWidths=[4.5*cm, 2*cm, 1.2*cm, 1.8*cm, 3.5*cm, 1*cm])
            t.setStyle(TABLE_STYLE)
            content.append(t)
        content.append(Spacer(1, 0.4*cm))
        content.extend(summary_section(pubs, faculty))

    # ---- CUSTOM FILTER REPORT ----
    else:
        content.append(Paragraph("Research Publication Report", style_title))
        if filter_by and filter_value:
            content.append(Paragraph(
                f"Filter: {filter_by.replace('_',' ').title()} = {filter_value}",
                style_subtitle))
        content.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor("#C9A84C")))
        content.append(Spacer(1, 0.3*cm))

        # Apply the selected filter
        if filter_by == "research_area":
            matched_sns   = [f["sn"] for f in faculty
                             if filter_value.lower() in f.get("ra", "").lower()]
            f_pubs        = [p for p in pubs
                             if any(sn in p.get("authors", []) for sn in matched_sns)]
            f_faculty     = [f for f in faculty if f["sn"] in matched_sns]
        elif filter_by == "year":
            f_pubs    = [p for p in pubs if p["year"] == filter_value]
            f_faculty = faculty
        elif filter_by == "pub_type":
            f_pubs    = [p for p in pubs if p["type"] == filter_value]
            f_faculty = faculty
        else:
            f_pubs    = pubs
            f_faculty = faculty

        content.append(Paragraph("Matching Publications", style_heading))
        rows = [["Title", "Author(s)", "Year", "Type", "Journal", "Cited"]]
        for p in sorted(f_pubs, key=lambda x: x["year"]):
            rows.append([
                linked(p["title"], p.get("url", "")),
                ", ".join(p.get("authors", [])),
                p["year"], p["type"], p["journal"],
                str(p.get("citations", 0))
            ])
        if len(rows) > 1:
            t = Table(rows, colWidths=[4.5*cm, 2*cm, 1.2*cm, 1.8*cm, 3.5*cm, 1*cm])
            t.setStyle(TABLE_STYLE)
            content.append(t)
        else:
            content.append(Paragraph("No publications match this filter.", style_normal))

        content.append(Spacer(1, 0.4*cm))
        content.extend(summary_section(f_pubs, f_faculty))

    # Build the PDF and send it to the browser as a download
    doc.build(content)
    buffer.seek(0)
    filename = f"RPDS_{report_type}_{datetime.now().strftime('%Y%m%d_%H%M')}.pdf"
    return send_file(buffer, mimetype="application/pdf",
                     as_attachment=True, download_name=filename)

# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":
    os.makedirs(DATA_DIR, exist_ok=True)
    app.run(debug=True)
