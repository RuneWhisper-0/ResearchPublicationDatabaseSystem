# Research Publication Database System (RPDS)
## Department of Mechanical Engineering, BUET

### How to Run

1. Install Python (3.8+) if not already installed.

2. Install Flask:
   ```
   pip install flask
   ```

3. Navigate to this folder:
   ```
   cd rpds
   ```

4. Run the app:
   ```
   python app.py
   ```

5. Open your browser and go to:
   ```
   http://localhost:5000
   ```

---

### Features
- **Dashboard** — Overview stats, recent publications, year/type charts
- **Faculty Management** — Add, edit, delete faculty profiles
- **Publication Management** — Add, edit, delete publications with validation
- **Search** — Search by keyword, faculty name/code, year, or type
- **Reports** — Faculty-wise, year-wise, and type-wise publication counts

### Data Storage
- All data is saved in the `data/` folder as JSON files:
  - `data/faculty.json` — Faculty records
  - `data/publications.json` — Publication records
- Data persists across program restarts (same as the C file-handling approach)

### Validation
- Year must be between 1900–2030
- Duplicate publication titles are rejected
- Duplicate faculty IDs and short names are rejected
