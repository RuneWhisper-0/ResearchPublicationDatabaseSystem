from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import json
import os

app = Flask(__name__)
app.secret_key = "rpds_buet_2024"

# ===================== DATA FILES =====================
FACULTY_FILE = "data/faculty.json"
PUB_FILE = "data/publications.json"

# ===================== LOAD / SAVE =====================

def load_faculty():
    if not os.path.exists(FACULTY_FILE):
        return []
    with open(FACULTY_FILE, "r") as f:
        return json.load(f)

def save_faculty(data):
    with open(FACULTY_FILE, "w") as f:
        json.dump(data, f, indent=2)

def load_publications():
    if not os.path.exists(PUB_FILE):
        return []
    with open(PUB_FILE, "r") as f:
        return json.load(f)

def save_publications(data):
    with open(PUB_FILE, "w") as f:
        json.dump(data, f, indent=2)

# ===================== HELPERS =====================

def faculty_id_exists(faculty_list, fid):
    return any(f["id"] == fid for f in faculty_list)

def faculty_sn_exists(faculty_list, sn):
    return any(f["sn"].upper() == sn.upper() for f in faculty_list)

def pub_title_exists(pub_list, title):
    return any(p["title"].lower() == title.lower() for p in pub_list)

def validate_year(year):
    try:
        y = int(year)
        return 1900 <= y <= 2030
    except:
        return False

def get_faculty_by_sn(faculty_list, sn):
    for f in faculty_list:
        if f["sn"].upper() == sn.upper():
            return f
    return None

# ===================== ROUTES =====================

@app.route("/")
def index():
    faculty = load_faculty()
    pubs = load_publications()

    # Stats for dashboard
    pub_types = {}
    for p in pubs:
        t = p["type"]
        pub_types[t] = pub_types.get(t, 0) + 1

    year_counts = {}
    for p in pubs:
        y = p["year"]
        year_counts[y] = year_counts.get(y, 0) + 1
    year_counts = dict(sorted(year_counts.items()))

    return render_template("index.html",
        faculty=faculty,
        pubs=pubs,
        pub_types=pub_types,
        year_counts=year_counts
    )

# ---- FACULTY ----

@app.route("/faculty")
def faculty_list():
    faculty = load_faculty()
    pubs = load_publications()
    # Count publications per faculty
    for f in faculty:
        f["pub_count"] = sum(1 for p in pubs if p["sn"].upper() == f["sn"].upper())
    return render_template("faculty.html", faculty=faculty)

@app.route("/faculty/add", methods=["GET", "POST"])
def add_faculty():
    if request.method == "POST":
        faculty = load_faculty()
        fid = request.form["id"].strip()
        sn = request.form["sn"].strip().upper()
        full_name = request.form["full_name"].strip()
        desi = request.form["desi"].strip()
        ra = request.form["ra"].strip()

        if not fid or not sn or not full_name or not desi or not ra:
            flash("All fields are required.", "error")
            return redirect(url_for("add_faculty"))
        if faculty_id_exists(faculty, fid):
            flash(f"Faculty ID '{fid}' already exists.", "error")
            return redirect(url_for("add_faculty"))
        if faculty_sn_exists(faculty, sn):
            flash(f"Short name '{sn}' already exists.", "error")
            return redirect(url_for("add_faculty"))

        faculty.append({"id": fid, "sn": sn, "full_name": full_name, "desi": desi, "ra": ra})
        save_faculty(faculty)
        flash(f"Faculty '{full_name}' added successfully!", "success")
        return redirect(url_for("faculty_list"))

    return render_template("add_faculty.html")

@app.route("/faculty/edit/<fid>", methods=["GET", "POST"])
def edit_faculty(fid):
    faculty = load_faculty()
    member = next((f for f in faculty if f["id"] == fid), None)
    if not member:
        flash("Faculty not found.", "error")
        return redirect(url_for("faculty_list"))

    if request.method == "POST":
        member["full_name"] = request.form["full_name"].strip()
        member["sn"] = request.form["sn"].strip().upper()
        member["desi"] = request.form["desi"].strip()
        member["ra"] = request.form["ra"].strip()
        save_faculty(faculty)
        flash("Faculty updated successfully!", "success")
        return redirect(url_for("faculty_list"))

    return render_template("edit_faculty.html", member=member)

@app.route("/faculty/delete/<fid>", methods=["POST"])
def delete_faculty(fid):
    faculty = load_faculty()
    faculty = [f for f in faculty if f["id"] != fid]
    save_faculty(faculty)
    flash("Faculty deleted.", "success")
    return redirect(url_for("faculty_list"))

# ---- PUBLICATIONS ----

@app.route("/publications")
def pub_list():
    pubs = load_publications()
    faculty = load_faculty()
    return render_template("publications.html", pubs=pubs, faculty=faculty)

@app.route("/publications/add", methods=["GET", "POST"])
def add_publication():
    faculty = load_faculty()
    if request.method == "POST":
        pubs = load_publications()
        title = request.form["title"].strip()
        year = request.form["year"].strip()
        ptype = request.form["type"].strip()
        sn = request.form["sn"].strip().upper()
        journal = request.form["journal"].strip()
        doi = request.form["doi"].strip()
        indexing = request.form["indexing"].strip()

        if not title or not year or not ptype or not sn or not journal:
            flash("Title, year, type, faculty, and journal are required.", "error")
            return redirect(url_for("add_publication"))
        if not validate_year(year):
            flash("Year must be a number between 1900 and 2030.", "error")
            return redirect(url_for("add_publication"))
        if pub_title_exists(pubs, title):
            flash("A publication with this title already exists.", "error")
            return redirect(url_for("add_publication"))
        if not faculty_sn_exists(faculty, sn):
            flash(f"Warning: Faculty short name '{sn}' not found. Record added anyway.", "warning")

        pubs.append({
            "title": title, "year": year, "type": ptype,
            "sn": sn, "journal": journal, "doi": doi, "indexing": indexing
        })
        save_publications(pubs)
        flash(f"Publication added successfully!", "success")
        return redirect(url_for("pub_list"))

    return render_template("add_publication.html", faculty=faculty)

@app.route("/publications/edit/<int:idx>", methods=["GET", "POST"])
def edit_publication(idx):
    pubs = load_publications()
    faculty = load_faculty()
    if idx >= len(pubs):
        flash("Publication not found.", "error")
        return redirect(url_for("pub_list"))

    pub = pubs[idx]
    if request.method == "POST":
        pub["title"] = request.form["title"].strip()
        pub["year"] = request.form["year"].strip()
        pub["type"] = request.form["type"].strip()
        pub["sn"] = request.form["sn"].strip().upper()
        pub["journal"] = request.form["journal"].strip()
        pub["doi"] = request.form["doi"].strip()
        pub["indexing"] = request.form["indexing"].strip()

        if not validate_year(pub["year"]):
            flash("Invalid year.", "error")
            return redirect(url_for("edit_publication", idx=idx))

        save_publications(pubs)
        flash("Publication updated!", "success")
        return redirect(url_for("pub_list"))

    return render_template("edit_publication.html", pub=pub, idx=idx, faculty=faculty)

@app.route("/publications/delete/<int:idx>", methods=["POST"])
def delete_publication(idx):
    pubs = load_publications()
    if idx < len(pubs):
        pubs.pop(idx)
        save_publications(pubs)
        flash("Publication deleted.", "success")
    return redirect(url_for("pub_list"))

# ---- SEARCH ----

@app.route("/search")
def search():
    query = request.args.get("q", "").strip()
    search_type = request.args.get("type", "keyword")
    pubs = load_publications()
    faculty = load_faculty()
    results = []

    if query:
        if search_type == "faculty":
            results = [p for p in pubs if p["sn"].upper() == query.upper()]
            # Also search by full name
            matched_sns = [f["sn"] for f in faculty if query.lower() in f["full_name"].lower()]
            for sn in matched_sns:
                extras = [p for p in pubs if p["sn"].upper() == sn.upper() and p not in results]
                results.extend(extras)
        elif search_type == "year":
            results = [p for p in pubs if p["year"] == query]
        elif search_type == "pubtype":
            results = [p for p in pubs if query.lower() in p["type"].lower()]
        else:  # keyword
            results = [p for p in pubs if
                query.lower() in p["title"].lower() or
                query.lower() in p["journal"].lower() or
                query.lower() in p.get("indexing", "").lower()
            ]

    return render_template("search.html", results=results, query=query,
                           search_type=search_type, faculty=faculty)

# ---- REPORTS ----

@app.route("/reports")
def reports():
    pubs = load_publications()
    faculty = load_faculty()

    # Faculty-wise count
    faculty_counts = []
    for f in faculty:
        count = sum(1 for p in pubs if p["sn"].upper() == f["sn"].upper())
        faculty_counts.append({"name": f["full_name"], "sn": f["sn"], "count": count})
    faculty_counts.sort(key=lambda x: x["count"], reverse=True)

    # Year-wise count
    year_counts = {}
    for p in pubs:
        year_counts[p["year"]] = year_counts.get(p["year"], 0) + 1
    year_counts = dict(sorted(year_counts.items()))

    # Type-wise count
    type_counts = {}
    for p in pubs:
        type_counts[p["type"]] = type_counts.get(p["type"], 0) + 1

    # Stats
    avg = round(len(pubs) / len(faculty), 2) if faculty else 0
    years = [int(p["year"]) for p in pubs if p["year"].isdigit()]
    min_year = min(years) if years else "N/A"
    max_year = max(years) if years else "N/A"

    return render_template("reports.html",
        faculty_counts=faculty_counts,
        year_counts=year_counts,
        type_counts=type_counts,
        total_pubs=len(pubs),
        total_faculty=len(faculty),
        avg=avg,
        min_year=min_year,
        max_year=max_year
    )

if __name__ == "__main__":
    os.makedirs("data", exist_ok=True)
    app.run(debug=True)
